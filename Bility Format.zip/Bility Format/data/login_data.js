//---------------------------User data----------------------
const users = [
  {
    id: "khaja",
    password: "khaja",
  },
  {
    id: "sharp",
    password: "sharp",
  },
  {
    id: "user2",
    password: "user2",
  },
  {
    id: "user3",
    password: "user3",
  },
  {
    id: "user4",
    password: "user4",
  },
  {
    id: "user5",
    password: "user5",
  },
];
